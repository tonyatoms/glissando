//
//  AppDelegate.h
//  glissando
//
//  Created by Tony Adams on 1/17/14.
//  Copyright (c) 2014 AT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
