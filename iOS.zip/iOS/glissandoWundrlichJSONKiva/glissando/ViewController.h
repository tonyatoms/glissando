//
//  ViewController.h
//  glissando
//
//  Created by Tony Adams on 1/17/14.
//  Copyright (c) 2014 AT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *humanReadableLabel;

@property (strong, nonatomic) IBOutlet UILabel *JSONSummaryLabel;

@end
