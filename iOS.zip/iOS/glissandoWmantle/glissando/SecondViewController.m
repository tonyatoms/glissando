//
//  SecondViewController.m
//  glissando
//
//  Created by Tony Adams on 1/16/14.
//  Copyright (c) 2014 AT. All rights reserved.
//

#import "SecondViewController.h"
#import "UserModel.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.adjustedGrossInputField.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    NSLog(@"textFieldShouldReturn: %@", textField.text );
    
    [textField resignFirstResponder];
    
    return YES;
}


-(void)textFieldDidEndEditing:(UITextField *)textField {

    if ([textField.text isEqualToString:@""]){
        
        NSLog(@"textViewShouldReturn got empty string so baiking");
        
        return;
    }
    
    NSLog(@"textViewShouldReturn got non-empty string");
    
    UIAlertView *helloEarthInputAlert = [[UIAlertView alloc]
                                         initWithTitle:@"some income, great! " message:[NSString stringWithFormat:@"Input: %@", textField.text]
                                         delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    
    // Display this message.
    [helloEarthInputAlert show];

    
    NSDictionary *jsonDict = kSomeParsedJSONDictionary;
    

    NSError *error;
    UserModel *aUser;
    if (![  aUser = [MTLJSONAdapter modelOfClass: UserModel.class fromJSONDictionary: jsonDict error: &error]]) {
        // Handle Error
        
        NSLog(@"error creating UserModel %@ ", error);
    }
    

}

/*
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField == self.adjustedGrossInputField) {
        textField.text = @"Don't edit me!";
    }
}

- (BOOL) textFieldShouldBeginEditing:(UITextField *)textField {
   
    NSLog(@"textFieldShouldBeginEditing");
    
    if (textField == self.adjustedGrossInputField &&
        [textField.text isEqualToString:@"No Change"]) {
        return NO;
    }
    return YES;
}
*/

@end
