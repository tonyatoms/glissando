//
//  SecondViewController.h
//  glissando
//
//  Created by Tony Adams on 1/16/14.
//  Copyright (c) 2014 AT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController  <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *adjustedGrossInputField;
@property (strong, nonatomic) IBOutlet UITextField *adjustedGrossInput;

@end
