#import "Expecta.h"

EXPMatcherInterface(conformTo, (Protocol *expected));
