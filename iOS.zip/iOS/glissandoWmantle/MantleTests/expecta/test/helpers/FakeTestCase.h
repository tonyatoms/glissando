#import "TestHelper.h"

@interface FakeTestCase : NSObject

- (void)failWithException:(NSException *)exception;

@end
