#import "___FILEBASENAME___.h"

@implementation ___VARIABLE_specHelperClass:identifier___ (___VARIABLE_specHelperCategory:identifier___)

@end
