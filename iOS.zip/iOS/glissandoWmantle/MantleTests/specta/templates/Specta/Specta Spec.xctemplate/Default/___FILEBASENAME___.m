#import "Specta.h"
___IMPORTHEADER_subjectClassName___

SpecBegin(___VARIABLE_subjectClassName:identifier___)



SpecEnd
